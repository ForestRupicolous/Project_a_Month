#include "gamepad.h"

Gamepad *snesGetGamepad(void);

