#include "gamepad.h"

Gamepad *snesmouseGetGamepad(void);
char isSnesMouse();

