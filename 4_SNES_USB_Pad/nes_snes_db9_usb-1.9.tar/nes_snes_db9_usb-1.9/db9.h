#include "gamepad.h"

Gamepad *db9GetGamepad(void);

