#include "gamepad.h"

Gamepad *tg16_GetGamepad(void);

