
extern const char snes_usbHidReportDescriptor[] PROGMEM;
