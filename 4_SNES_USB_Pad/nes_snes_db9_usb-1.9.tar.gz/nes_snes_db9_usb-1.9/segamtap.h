#include "gamepad.h"

Gamepad *segamtapGetGamepad(void);

