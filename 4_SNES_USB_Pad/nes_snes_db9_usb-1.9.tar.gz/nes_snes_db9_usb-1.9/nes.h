#include "gamepad.h"

Gamepad *nesGetGamepad(void);

