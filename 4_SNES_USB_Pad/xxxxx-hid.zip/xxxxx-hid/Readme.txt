A low budget USB sensor input device for Pure Data/Supercollider and
other free softwares based around the ATmega8 microcontroller. This
allows for very fast, multiple sensor input at high resolutions on a
range of platforms (GNU/Linux, MAC OS X, Windows). The device is based
on Objective Development's USB driver.

Six analogue inputs (0-5v) provide ten bit resolution. Sensors are
attached to the P7 connector with Pin 1 as GND, Pin 2 as +5v, and all
sensor six inputs following. P8 jumper is for four digital or
pushbutton inputs (Pins 6,4,5,3 on the jumper).

The circuit diagram is included in the distribution as:
atmega8_minimal_usb.pdf. The firmware directory contains all code
which can be built using the make utility and programmed onto the
ATmega8 using avrdude (for example). Full documentation is available
at:

http://1010.co.uk/avrhid.html

Martin Howse
